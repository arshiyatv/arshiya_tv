ARSHIA TV PRO v3.1
==================

آپلود: کل محتویات این پوشه در ریشه ریپو (core و assets باید باشند)
سایت: https://arshiyatv.github.io/arshiya_tv/

نصب گوشی: کروم → ⋮ → افزودن به صفحه اصلی  یا دکمه «نصب» داخل اپ

پراکسی (برای شبکه‌های داخلی Telewebion):
1) Cloudflare Workers → کد worker/proxy.js
2) در core/brain.js :
   proxyBase: "https://YOUR.workers.dev/?u="

رادیو جوان بدون پراکسی کار می‌کند.
